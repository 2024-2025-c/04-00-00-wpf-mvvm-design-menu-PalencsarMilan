﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace KretaBasicSchoolSystem.Desktop.ViewModels.Base
{
    public  abstract class BaseViewModel : ObservableObject
    {
    }
}
